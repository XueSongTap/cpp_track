#!/usr/bin/env sh

cmake -H. -B_build

cmake --build _build
